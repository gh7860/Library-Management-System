# member.py
class Member:
    def __init__(self, member_id, name, member_type="student"):
        self.member_id = member_id
        self.name = name
        self.member_type = member_type
        self.borrowed = []

    def can_borrow(self):
        return len(self.borrowed) < 5

    def __str__(self):
        return f"{self.name} ({self.member_id}) | Type: {self.member_type} | Borrowed books: {len(self.borrowed)}"
