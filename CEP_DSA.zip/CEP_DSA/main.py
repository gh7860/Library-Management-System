from book import Book
from avl_tree import AVLTree
from hash_table import HashTable
from member import Member
from data import books_data, members_data  

book_tree = AVLTree()
root = None
title_index = HashTable()
author_index = HashTable()
members = HashTable()

MAX_BOOKS = 200
MAX_MEMBERS = 50
MAX_BORROW = 2 

def normalize(text):
    return text.lower().strip() if text else ""

# ---------- Book Management ----------
def add_book(book):
    global root
    if count_books() >= MAX_BOOKS:
        print("Library book capacity reached!")
        return False
    if search_by_isbn(book.isbn):
        print(f"Book with ISBN {book.isbn} already exists!")
        return False

    root = book_tree.insert(root, book.isbn, book)
    title_index.insert(normalize(book.title), book.isbn)
    author_key = normalize(book.author)
    isbn_list = author_index.search(author_key)
    if isbn_list is None:
        isbn_list = []
    isbn_list.append(book.isbn)
    author_index.insert(author_key, isbn_list)
    return True

def delete_book(isbn):
    global root
    book = search_by_isbn(isbn)
    if not book:
        print("Book not found")
        return False
    root = book_tree.delete(root, isbn)
    title_index.delete(normalize(book.title))
    author_isbns = author_index.search(normalize(book.author))
    if author_isbns:
        author_isbns.remove(isbn)
        if author_isbns:
            author_index.insert(normalize(book.author), author_isbns)
        else:
            author_index.delete(normalize(book.author))
    print(f"Book '{book.title}' deleted successfully")
    return True

# ---------- Member Management ----------
def add_member(mid, name, member_type="student"):
    if count_members() >= MAX_MEMBERS:
        print("Member capacity reached!")
        return False
    if members.search(mid):
        print(f"Member ID {mid} already exists!")
        return False
    members.insert(mid, Member(mid, name, member_type))
    return True

# ---------- Counts ----------
def count_books():
    books = []
    book_tree.inorder(root, books)
    return len(books)

def count_members():
    total = 0
    for bucket in members.table:
        total += len(bucket)
    return total

# ---------- Searching ----------
def search_by_title(title):
    if not title:
        return None
    isbn = title_index.search(normalize(title))
    return book_tree.search(root, isbn) if isbn else None

def search_by_isbn(isbn):
    if not isbn:
        return None
    return book_tree.search(root, isbn)

def search_by_author(author):
    if not author:
        return []
    isbn_list = author_index.search(normalize(author))
    books = []
    if isbn_list:
        for isbn in isbn_list:
            book = book_tree.search(root, isbn)
            if book:
                books.append(book)
    return books

# ---------- Borrow & Return ----------
def borrow_book(mid, isbn):
    member = members.search(mid)
    book = book_tree.search(root, isbn)
    if not member:
        return "Member not found"
    if not book:
        return "Book not found"
    if book.available_copies <= 0:
        return "Book unavailable"
    if len(member.borrowed) >= MAX_BORROW:
        return f"Borrow limit reached ({MAX_BORROW} books)"
    if isbn in member.borrowed:
        return "You already borrowed this book"

    book.available_copies -= 1
    member.borrowed.append(isbn)
    return f"Book borrowed successfully by {member.name}"

def return_book(mid, isbn):
    member = members.search(mid)
    book = book_tree.search(root, isbn)
    if not member:
        return "Member not found"
    if not book:
        return "Book not found"
    if isbn not in member.borrowed:
        return "This book was not borrowed by the member"

    member.borrowed.remove(isbn)
    book.available_copies += 1
    return f"Book returned successfully by {member.name}"

# ---------- Reporting ----------
def show_all_books(available_only=False):
    books = []
    book_tree.inorder(root, books)
    
    if not books:
        print("No books in the library yet!")
        return
    for book in books:
        if available_only and book.available_copies == 0:
            continue
        print(f"{book} | Available copies: {book.available_copies}")

def show_member_books(mid):
    member = members.search(mid)
    if not member:
        print("Member not found")
        return
    if not member.borrowed:
        print(f"{member.name} has not borrowed any books")
        return
    print(f"{member.name} has borrowed:")
    for isbn in member.borrowed:
        book = book_tree.search(root, isbn)
        if book:
            print(f"- {book.title} by {book.author}")

def list_books_by_author(author):
    books = search_by_author(author)
    if not books:
        print("No books found for this author")
        return
    print(f"Books by {author}:")
    for book in books:
        print(f"- {book} | Available copies: {book.available_copies}")

# ---------- Load initial data ----------
for b in books_data:
    add_book(Book(*b))
for m in members_data:
    add_member(m[0], m[1])

# ---------- Interactive Menu ----------
def menu():
    while True:
        print("\n--- Library Menu ---")
        print("1. Search by title")
        print("2. Search by ISBN")
        print("3. Search by author")
        print("4. Borrow a book")
        print("5. Return a book")
        print("6. Show all books")
        print("7. Show available books")
        print("8. Show member borrowed books")
        print("9. Add book")
        print("10. Delete book")
        print("11. Add member")
        print("12. Exit")

        choice = input("Enter your choice (1-12): ").strip()
        if choice == "1":
            title = input("Enter the book title: ").strip()
            book = search_by_title(title)
            print(f"Found: {book}" if book else "Book not found")
        elif choice == "2":
            isbn = input("Enter ISBN: ").strip()
            book = search_by_isbn(isbn)
            print(f"Found: {book}" if book else "Book not found")
        elif choice == "3":
            author = input("Enter author name: ").strip()
            list_books_by_author(author)
        elif choice == "4":
            mid = input("Enter member ID: ").strip()
            title = input("Enter book title: ").strip()
            book = search_by_title(title)
            print(borrow_book(mid, book.isbn) if book else "Book not found")
        elif choice == "5":
            mid = input("Enter member ID: ").strip()
            title = input("Enter book title to return: ").strip()
            book = search_by_title(title)
            print(return_book(mid, book.isbn) if book else "Book not found")
        elif choice == "6":
            show_all_books()
        elif choice == "7":
            show_all_books(available_only=True)
        elif choice == "8":
            mid = input("Enter member ID: ").strip()
            show_member_books(mid)
        elif choice == "9":
            isbn = input("ISBN: ").strip()
            if search_by_isbn(isbn):
                print("Book already exists!")
                continue
            title = input("Title: ").strip()
            author = input("Author: ").strip()
            try:
                year = int(input("Year: ").strip())
                copies = int(input("Copies: ").strip())
            except ValueError:
                print("Invalid input for year or copies!")
                continue
            category = input("Category: ").strip()
            added = add_book(Book(isbn, title, author, year, category, copies))
            if added:
                print("Book added successfully")
        elif choice == "10":
            isbn = input("Enter ISBN to delete: ").strip()
            delete_book(isbn)
        elif choice == "11":
            mid = input("Enter member ID: ").strip()
            name = input("Enter member name: ").strip()
            member_type = input("Enter member type (student/faculty): ").strip() or "student"
            added = add_member(mid, name, member_type)
            if added:
                print(f"Member {name} added successfully!")
        elif choice == "12":
            print("Exiting library system...")
            break
        else:
            print("Invalid choice. Enter 1-12.")

if __name__ == "__main__":
    menu()
